export * from './pages/SoftwarePage';
