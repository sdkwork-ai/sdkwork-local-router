export * from './pages/NewsPage';
